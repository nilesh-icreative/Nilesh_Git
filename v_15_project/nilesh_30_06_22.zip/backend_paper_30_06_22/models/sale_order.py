from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    product_id = fields.Many2one(comodel_name="product.product")
    product_qty = fields.Float()

    @api.onchange('product_qty')
    def _calculate_length(self):
        """
        Calculate Subtotal
        """
        if self.product_id:
            for sale_rec in self.order_line:
                if sale_rec.product_id.id == self.product_id.id:
                    sale_rec.product_uom_qty = self.product_qty
                    total_length = sale_rec.product_uom_qty * sale_rec.length
                    sub_total = sale_rec.product_uom_qty * sale_rec.length * sale_rec.price_unit
                    sale_rec.total_length = total_length
                    sale_rec.price_subtotal = sub_total

    @api.onchange('product_id')
    def _product_onchange(self):
        """
        generated Sale Order Line in Select Product
        """

        order_line = []
        for sale_rec in self:
            order_line.append((0, 0, {
                'product_id': sale_rec.product_id.id,
                'product_uom_qty': sale_rec.product_qty,
            }))

        self.update({
            'order_line': order_line
        })

    #     order_line = []
    #     if self.product_id and self.product_qty:
    #         for pro_rec in product_obj:
    #             order_line.append((0, 0, {
    #                 'product_id': pro_rec.id,
    #                 'name': pro_rec.display_name,
    #             }))
    #     print("===========\n\n", order_line)
    #     self.order_line = order_line


